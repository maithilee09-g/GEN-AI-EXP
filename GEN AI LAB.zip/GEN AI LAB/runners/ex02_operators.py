"""
Runner for Experiment 2: Python Operators & TensorFlow Tensor Operations
Preserves original notebook logic from EX2_GAI_65.ipynb while safely handling input()
"""

import sys
import subprocess
import numpy as np

try:
    import tensorflow as tf
except ImportError:
    tf = None

from registry import run_safe_subprocess, get_python_executable

def run_experiment_2_subprocess(a: int = 10, b: int = 5) -> dict:
    """
    Executes Experiment 2 operations via subprocess using Python interpreter and piped stdin.
    This guarantees safe non-blocking execution while preserving the original input() flow.
    """
    python_script = """
import sys
try:
    a = int(input())
    b = int(input())
except Exception as e:
    a, b = 10, 5

print(f"Inputs received: a = {a}, b = {b}")

# Arithmetic
print("--- Arithmetic Operations ---")
print("Addition =", a + b)
print("Subtraction =", a - b)
print("Multiplication =", a * b)
print("Division =", a / b if b != 0 else "Undefined")
print("Floor Division =", a // b if b != 0 else "Undefined")
print("Modulus =", a % b if b != 0 else "Undefined")
print("Exponent =", a ** b if b < 20 else "Value too large")

# Assignment
print("\\n--- Assignment Operations ---")
x = a
print("Initial x =", x)
x += b
print("x += b ->", x)
x -= b
print("x -= b ->", x)
x *= b
print("x *= b ->", x)

# Comparison
print("\\n--- Comparison Operations ---")
print("a == b:", a == b)
print("a != b:", a != b)
print("a > b:", a > b)
print("a < b:", a < b)
print("a >= b:", a >= b)
print("a <= b:", a <= b)

# Logical
print("\\n--- Logical Operations ---")
print("a > 0 and b > 0:", a > 0 and b > 0)
print("a > 0 or b < 0:", a > 0 or b < 0)
print("not (a > b):", not (a > b))

# Bitwise
print("\\n--- Bitwise Operations ---")
print("a & b =", a & b)
print("a | b =", a | b)
print("a ^ b =", a ^ b)
print("~a =", ~a)
print("a << 1 =", a << 1)
print("a >> 1 =", a >> 1)

# TensorFlow Tensors
print("\\n--- TensorFlow Tensor Demonstration ---")
try:
    import tensorflow as tf
    scalar = tf.constant(a)
    vector = tf.constant([1, 2, 3, b])
    matrix = tf.constant([[1, 2], [a, b]])
    tensor_3d = tf.constant([[[1, 2], [3, 4]], [[5, 6], [a, b]]])

    print("Scalar:\\n", scalar)
    print("Vector:\\n", vector)
    print("Matrix:\\n", matrix)
    print("3-D Tensor shape:", tensor_3d.shape)
    print("Tensor Rank:", tf.rank(matrix).numpy())
    print("Tensor Dtype:", matrix.dtype)

    # Math Ops
    t_a = tf.constant([a, 20, 30])
    t_b = tf.constant([b, 4, 5])
    print("TF Addition:", tf.add(t_a, t_b).numpy())
    print("TF Multiply:", tf.multiply(t_a, t_b).numpy())

    # Reshape
    x_tensor = tf.constant([1, 2, 3, 4, a, b])
    reshaped = tf.reshape(x_tensor, (2, 3))
    print("Reshaped (2, 3):\\n", reshaped.numpy())
except ImportError:
    print("TensorFlow not installed in current subprocess environment.")
"""
    stdin_data = f"{a}\n{b}\n"
    # Execute using preferred Python executable (Python 3.11 has full TF 2.20)
    res = run_safe_subprocess([get_python_executable(), "-c", python_script], stdin_input=stdin_data, timeout=35)
    return res

def run_experiment_2_interactive(a: int = 10, b: int = 5) -> dict:
    """
    Executes TensorFlow and Python operations in-process, returning structured outputs.
    """
    results = {}
    
    # Python operators
    results["arithmetic"] = {
        "Addition (a + b)": a + b,
        "Subtraction (a - b)": a - b,
        "Multiplication (a * b)": a * b,
        "Division (a / b)": round(a / b, 4) if b != 0 else "Division by zero",
        "Floor Division (a // b)": a // b if b != 0 else "Division by zero",
        "Modulus (a % b)": a % b if b != 0 else "Division by zero",
        "Exponent (a ** b)": a ** b if abs(b) < 15 else "Exponent capped to prevent overflow"
    }
    
    results["logical"] = {
        "a > 0 and b > 0": a > 0 and b > 0,
        "a > 0 or b < 0": a > 0 or b < 0,
        "not (a > b)": not (a > b)
    }
    
    results["comparison"] = {
        "a == b": a == b,
        "a != b": a != b,
        "a > b": a > b,
        "a < b": a < b,
        "a >= b": a >= b,
        "a <= b": a <= b
    }
    
    results["bitwise"] = {
        "Bitwise AND (a & b)": a & b,
        "Bitwise OR (a | b)": a | b,
        "Bitwise XOR (a ^ b)": a ^ b
    }
    
    if tf is not None:
        # Native TensorFlow operations
        scalar = tf.constant(a)
        vector = tf.constant([1, 2, 3, b])
        matrix = tf.constant([[1, 2], [a, b]])
        tensor_3d = tf.constant([[[1, 2], [3, 4]], [[5, 6], [a, b]]])
        
        results["tensors"] = {
            "scalar": {"value": scalar.numpy().tolist(), "shape": str(scalar.shape), "rank": 0},
            "vector": {"value": vector.numpy().tolist(), "shape": str(vector.shape), "rank": 1},
            "matrix": {"value": matrix.numpy().tolist(), "shape": str(matrix.shape), "rank": 2},
            "tensor_3d": {"value": tensor_3d.numpy().tolist(), "shape": str(tensor_3d.shape), "rank": 3}
        }
        
        t_a = tf.constant([a, 20, 30], dtype=tf.float32)
        t_b = tf.constant([b if b != 0 else 1, 4, 5], dtype=tf.float32)
        
        results["tf_math"] = {
            "tf.add(t_a, t_b)": tf.add(t_a, t_b).numpy().tolist(),
            "tf.subtract(t_a, t_b)": tf.subtract(t_a, t_b).numpy().tolist(),
            "tf.multiply(t_a, t_b)": tf.multiply(t_a, t_b).numpy().tolist(),
            "tf.divide(t_a, t_b)": tf.divide(t_a, t_b).numpy().tolist(),
            "tf.reduce_mean(t_a)": float(tf.reduce_mean(t_a).numpy()),
            "tf.reduce_max(t_a)": float(tf.reduce_max(t_a).numpy())
        }
        
        x_tensor = tf.constant([1, 2, 3, 4, a, b])
        reshaped = tf.reshape(x_tensor, (2, 3))
        results["reshape"] = {
            "original_shape": [6],
            "reshaped_shape": [2, 3],
            "reshaped_matrix": reshaped.numpy().tolist()
        }
    else:
        # NumPy tensor calculations with diagnostic note
        results["tensors"] = {
            "scalar": {"value": a, "shape": "()", "rank": 0},
            "vector": {"value": [1, 2, 3, b], "shape": "(4,)", "rank": 1},
            "matrix": {"value": [[1, 2], [a, b]], "shape": "(2, 2)", "rank": 2},
            "tensor_3d": {"value": [[[1, 2], [3, 4]], [[5, 6], [a, b]]], "shape": "(2, 2, 2)", "rank": 3}
        }
        t_a = np.array([a, 20, 30], dtype=np.float32)
        t_b = np.array([b if b != 0 else 1, 4, 5], dtype=np.float32)
        results["tf_math"] = {
            "tf.add(t_a, t_b)": (t_a + t_b).tolist(),
            "tf.subtract(t_a, t_b)": (t_a - t_b).tolist(),
            "tf.multiply(t_a, t_b)": (t_a * t_b).tolist(),
            "tf.divide(t_a, t_b)": (t_a / t_b).tolist(),
            "tf.reduce_mean(t_a)": float(np.mean(t_a)),
            "tf.reduce_max(t_a)": float(np.max(t_a))
        }
        x_arr = np.array([1, 2, 3, 4, a, b])
        results["reshape"] = {
            "original_shape": [6],
            "reshaped_shape": [2, 3],
            "reshaped_matrix": x_arr.reshape(2, 3).tolist()
        }
    
    return {
        "success": True,
        "results": results,
        "mode": "Native TensorFlow 2.x" if tf is not None else "Array Tensor Engine (TF available via Subprocess mode)"
    }
