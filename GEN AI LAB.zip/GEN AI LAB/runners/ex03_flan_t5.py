"""
Runner for Experiment 3: AI Question-Answering System with FLAN-T5
Preserves original notebook logic from 65-EX3-GEN-AI.ipynb
"""

import time
import torch

_MODEL_CACHE = {}

def get_flan_t5_pipeline(model_id: str = "google/flan-t5-base"):
    """
    Lazy-loads and caches FLAN-T5 model and tokenizer to prevent re-downloads.
    """
    global _MODEL_CACHE
    if model_id in _MODEL_CACHE:
        return _MODEL_CACHE[model_id]
        
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    device = "cuda" if torch.cuda.is_available() else "cpu"
    
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    model = AutoModelForSeq2SeqLM.from_pretrained(model_id)
    model = model.to(device)
    
    _MODEL_CACHE[model_id] = (tokenizer, model, device)
    return tokenizer, model, device

def run_experiment_3(question: str, max_new_tokens: int = 150, model_id: str = "google/flan-t5-base") -> dict:
    """
    Generates answer using FLAN-T5 according to Experiment 3 implementation.
    """
    if not question or not question.strip():
        return {
            "success": False,
            "error": "Please enter a non-empty question."
        }
        
    start_time = time.time()
    try:
        tokenizer, model, device = get_flan_t5_pipeline(model_id)
        
        prompt = (
            "Answer the following question clearly and accurately. "
            "If the question is asking for an explanation, explain it in simple language. "
            "Question: " + question
        )
        
        inputs = tokenizer(
            prompt,
            return_tensors="pt",
            truncation=True,
            max_length=512
        ).to(device)
        
        with torch.no_grad():
            outputs = model.generate(
                **inputs,
                max_new_tokens=int(max_new_tokens),
                num_beams=4,
                early_stopping=True
            )
            
        answer = tokenizer.decode(
            outputs[0],
            skip_special_tokens=True
        )
        
        elapsed = time.time() - start_time
        return {
            "success": True,
            "question": question,
            "prompt": prompt,
            "answer": answer,
            "device": str(device),
            "model_id": model_id,
            "elapsed_seconds": round(elapsed, 2)
        }
    except Exception as e:
        return {
            "success": False,
            "question": question,
            "error": str(e),
            "device": "cpu",
            "elapsed_seconds": round(time.time() - start_time, 2)
        }
