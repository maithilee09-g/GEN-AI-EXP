"""
Runner for Experiment 7: StyleGAN Architecture for Face Generation
Preserves original StyleGAN (Mapping Network, AdaIN, Style Mixing) from EX7-65-StyleGAN_Face_Generation2.ipynb
"""

import time
import torch
import torch.nn as nn
import numpy as np
import matplotlib.pyplot as plt
import torchvision.utils as vutils

class PixelNorm(nn.Module):
    def __init__(self, eps=1e-8):
        super().__init__()
        self.eps = eps
    def forward(self, x):
        return x * torch.rsqrt(torch.mean(x ** 2, dim=-1, keepdim=True) + self.eps)

class MappingNetwork(nn.Module):
    """8-layer MLP Mapping Network: maps z (Z-space) -> w (disentangled W-space)"""
    def __init__(self, z_dim=512, w_dim=512, num_layers=8):
        super().__init__()
        layers = [PixelNorm()]
        for _ in range(num_layers):
            layers.extend([nn.Linear(z_dim, w_dim), nn.LeakyReLU(0.2)])
        self.mapping = nn.Sequential(*layers)
        
    def forward(self, z):
        return self.mapping(z)

class AdaIN(nn.Module):
    """Adaptive Instance Normalization layer: aligns mean/variance to style y"""
    def __init__(self, in_channels, w_dim=512):
        super().__init__()
        self.norm = nn.InstanceNorm2d(in_channels)
        self.style_transform = nn.Linear(w_dim, in_channels * 2)
        
    def forward(self, x, w):
        style = self.style_transform(w).unsqueeze(-1).unsqueeze(-1)
        gamma, beta = style.chunk(2, dim=1)
        return (1 + gamma) * self.norm(x) + beta

class MiniSynthesisBlock(nn.Module):
    """Synthesis block with AdaIN and noise injection"""
    def __init__(self, in_c, out_c, w_dim=512):
        super().__init__()
        self.conv = nn.Conv2d(in_c, out_c, 3, padding=1)
        self.adain = AdaIN(out_c, w_dim)
        self.act = nn.LeakyReLU(0.2)
        
    def forward(self, x, w):
        x = self.conv(x)
        x = self.adain(x, w)
        return self.act(x)

class StyleGANGenerator(nn.Module):
    def __init__(self, z_dim=512, w_dim=512):
        super().__init__()
        self.mapping = MappingNetwork(z_dim, w_dim, num_layers=4)
        self.const = nn.Parameter(torch.randn(1, 128, 4, 4))
        self.block1 = MiniSynthesisBlock(128, 64, w_dim)
        self.upsample = nn.Upsample(scale_factor=2, mode="bilinear", align_corners=False)
        self.block2 = MiniSynthesisBlock(64, 32, w_dim)
        self.to_rgb = nn.Sequential(
            nn.Conv2d(32, 3, 1),
            nn.Tanh()
        )
        
    def forward(self, z, truncation_psi=1.0, w_avg=None):
        w = self.mapping(z)
        if w_avg is not None and truncation_psi < 1.0:
            w = w_avg + truncation_psi * (w - w_avg)
            
        x = self.const.repeat(z.size(0), 1, 1, 1)
        x = self.block1(x, w)
        x = self.upsample(x)
        x = self.block2(x, w)
        x = self.to_rgb(x)
        return x, w

def run_experiment_7(truncation_psi: float = 0.7, seed_a: int = 42, seed_b: int = 101) -> dict:
    """
    Executes StyleGAN Mapping Network, Truncation Trick, and Style Mixing demonstration.
    """
    start_time = time.time()
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    generator = StyleGANGenerator(z_dim=128, w_dim=128).to(device)
    generator.eval()
    
    # 1. Sample Z-vectors
    torch.manual_seed(seed_a)
    z_a = torch.randn(1, 128, device=device)
    torch.manual_seed(seed_b)
    z_b = torch.randn(1, 128, device=device)
    
    # Compute approximate w_avg
    with torch.no_grad():
        sample_z = torch.randn(50, 128, device=device)
        w_samples = generator.mapping(sample_z)
        w_avg = w_samples.mean(dim=0, keepdim=True)
        
        # Generation with Truncation Trick
        img_a_full, w_a = generator(z_a, truncation_psi=1.0, w_avg=w_avg)
        img_a_trunc, _ = generator(z_a, truncation_psi=truncation_psi, w_avg=w_avg)
        img_b_full, w_b = generator(z_b, truncation_psi=1.0, w_avg=w_avg)
        
        # Style Mixing: coarse style from A, fine style from B
        w_mixed = 0.6 * w_a + 0.4 * w_b
        x = generator.const.repeat(1, 1, 1, 1)
        x = generator.block1(x, w_a) # Coarse structure from A
        x = generator.upsample(x)
        x = generator.block2(x, w_b) # Fine texture from B
        img_mixed = generator.to_rgb(x)
        
    # Collate comparison figure
    comparison = torch.cat([img_a_full, img_a_trunc, img_b_full, img_mixed], dim=0).detach().cpu()
    grid = vutils.make_grid(comparison, nrow=4, normalize=True, padding=2)
    
    fig, ax = plt.subplots(figsize=(10, 3.2))
    ax.axis("off")
    ax.imshow(np.transpose(grid.numpy(), (1, 2, 0)))
    ax.set_title(
        f"StyleGAN Synthesis | Identity A (Full) | Identity A (Psi={truncation_psi}) | Identity B | Style Mixed (A+B)",
        fontsize=11, fontweight="bold"
    )
    plt.tight_layout()
    
    elapsed = time.time() - start_time
    diagnostics = (
        f"StyleGAN Architecture: 4-layer MLP Mapping Network (Z->W), AdaIN modulation, "
        f"Truncation Trick (psi={truncation_psi}), and dual-latent style mixing. "
        f"Executed in {elapsed:.2f}s on {device}."
    )
    
    return {
        "success": True,
        "figure": fig,
        "truncation_psi": truncation_psi,
        "seed_a": seed_a,
        "seed_b": seed_b,
        "device": str(device),
        "diagnostics": diagnostics,
        "elapsed_seconds": round(elapsed, 2)
    }
