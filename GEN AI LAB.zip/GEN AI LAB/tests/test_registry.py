"""
Unit and Integration Tests for GenAI Practical Lab Registry & Runners
"""

import os
import unittest
from registry import (
    EXPERIMENTS,
    get_all_experiments,
    get_experiment_by_id,
    check_package_installed,
    check_experiment_dependencies,
    run_safe_subprocess,
    WORKSPACE_DIR
)
from runners.ex01_eda import run_experiment_1
from runners.ex02_operators import run_experiment_2_interactive, run_experiment_2_subprocess
from runners.ex05_vae import check_vae_model_files, generate_digit_image
from runners.ex09_rag_assistant import split_text

class TestGenAIRegistry(unittest.TestCase):
    
    def test_experiment_count(self):
        """Ensure all experiments are registered."""
        experiments = get_all_experiments()
        self.assertGreaterEqual(len(experiments), 10)
        
    def test_original_files_exist(self):
        """Verify that every registered experiment points to an existing file in the workspace."""
        for exp in get_all_experiments():
            full_path = os.path.join(WORKSPACE_DIR, exp["filename"])
            self.assertTrue(
                os.path.exists(full_path),
                f"Original file missing: {exp['filename']} (Full: {full_path})"
            )
            
    def test_terminal_input_flags(self):
        """Verify that experiments requiring input() are properly flagged."""
        exp2 = get_experiment_by_id("exp2")
        self.assertTrue(exp2["has_terminal_input"])
        self.assertFalse(exp2["subprocess_safe"])
        
        exp4 = get_experiment_by_id("exp4")
        self.assertTrue(exp4["has_terminal_input"])
        self.assertFalse(exp4["subprocess_safe"])
        
    def test_check_dependencies(self):
        """Verify dependency checking function returns boolean dictionary."""
        deps = check_experiment_dependencies("exp1")
        self.assertIn("pandas", deps)
        self.assertTrue(deps["pandas"])
        
    def test_safe_subprocess_execution(self):
        """Test that run_safe_subprocess executes safely and captures output."""
        res = run_safe_subprocess([os.sys.executable, "-c", "print('Antigravity Test OK')"])
        self.assertTrue(res["success"])
        self.assertIn("Antigravity Test OK", res["stdout"])
        
    def test_ex01_eda_runner(self):
        """Test Experiment 1 EDA runner on iris dataset."""
        res = run_experiment_1(dataset_name="iris", plot_type="distribution")
        self.assertTrue(res["success"])
        self.assertIsNotNone(res["dataframe"])
        self.assertIsNotNone(res["figure"])
        self.assertEqual(res["dataframe"].shape[0], 150)
        
    def test_ex02_operators_interactive(self):
        """Test Experiment 2 interactive math and tensor runner."""
        res = run_experiment_2_interactive(a=12, b=4)
        self.assertTrue(res["success"])
        self.assertEqual(res["results"]["arithmetic"]["Addition (a + b)"], 16)
        self.assertEqual(res["results"]["arithmetic"]["Multiplication (a * b)"], 48)
        self.assertEqual(res["results"]["tensors"]["scalar"]["value"], 12)
        
    def test_ex02_operators_piped_subprocess(self):
        """Test Experiment 2 safe subprocess execution with piped stdin."""
        res = run_experiment_2_subprocess(a=7, b=3)
        self.assertTrue(res["success"])
        self.assertIn("Addition = 10", res["stdout"])
        self.assertIn("Subtraction = 4", res["stdout"])
        
    def test_ex05_vae_status(self):
        """Verify VAE model file detection."""
        status = check_vae_model_files()
        self.assertIn("models_ready", status)
        gen = generate_digit_image(selected_digit=7, temperature=0.5)
        self.assertTrue(gen["success"])
        self.assertEqual(gen["selected_digit"], 7)
        self.assertIsNotNone(gen["image"])
        
    def test_ex09_text_chunking(self):
        """Verify RAG chunking logic."""
        text = "ABCDEFGHIJ" * 50
        chunks = split_text(text, chunk_size=100, overlap=20)
        self.assertGreater(len(chunks), 1)

if __name__ == "__main__":
    unittest.main()
