import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

print(f"Testing imports under Python: {sys.version}")

runners = [
    'ex01_eda',
    'ex02_operators',
    'ex03_flan_t5',
    'ex04_diffusion',
    'ex05_vae',
    'ex06_dcgan',
    'ex07_stylegan',
    'ex08_musicgen',
    'ex09_rag_assistant'
]

for r in runners:
    try:
        __import__(f'runners.{r}')
        print(f"  [+] {r}: OK")
    except Exception as e:
        print(f"  [-] {r}: ERROR -> {e}")
