"""
End-to-End Test for All 10 Experiment Runners
"""

import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from runners.ex01_eda import run_experiment_1
from runners.ex02_operators import run_experiment_2_interactive, run_experiment_2_subprocess
from runners.ex04_diffusion import run_experiment_4
from runners.ex05_vae import generate_digit_image
from runners.ex06_dcgan import run_experiment_6
from runners.ex07_stylegan import run_experiment_7
from runners.ex08_musicgen import run_experiment_8
from runners.ex09_rag_assistant import run_experiment_9

def main():
    print("=== Testing Exp 1 (EDA) ===")
    r1 = run_experiment_1("iris", "distribution")
    assert r1["success"], "Exp 1 failed"
    print("Exp 1 OK | Shape:", r1["dataframe"].shape)

    print("\n=== Testing Exp 2 (Operators Interactive) ===")
    r2_int = run_experiment_2_interactive(10, 5)
    assert r2_int["success"], "Exp 2 interactive failed"
    print("Exp 2 Interactive OK | Addition:", r2_int["results"]["arithmetic"]["Addition (a + b)"])

    print("\n=== Testing Exp 2 (Operators Subprocess with Piped stdin) ===")
    r2_sub = run_experiment_2_subprocess(10, 5)
    assert r2_sub["success"], "Exp 2 subprocess failed"
    print("Exp 2 Subprocess OK | Returncode:", r2_sub["returncode"])

    print("\n=== Testing Exp 4 (Stable Diffusion Adapter) ===")
    r4 = run_experiment_4("cyberpunk neon car", "2", "", 1)
    assert r4["success"], "Exp 4 failed"
    print("Exp 4 OK | Generated images:", len(r4["images"]))

    print("\n=== Testing Exp 5 (VAE Digit Synthesis) ===")
    r5 = generate_digit_image(7, 0.7)
    assert r5["success"], "Exp 5 failed"
    print("Exp 5 OK | Selected digit:", r5["selected_digit"])

    print("\n=== Testing Exp 6 (DCGAN Face Generation) ===")
    r6 = run_experiment_6(num_faces=4, seed=42)
    assert r6["success"], "Exp 6 failed"
    print("Exp 6 OK | Figure generated successfully")

    print("\n=== Testing Exp 7 (StyleGAN Architecture) ===")
    r7 = run_experiment_7(0.7, 42, 101)
    assert r7["success"], "Exp 7 failed"
    print("Exp 7 OK | Figure generated successfully")

    print("\n=== Testing Exp 8 (MusicGen Audio Synthesis) ===")
    r8 = run_experiment_8("energetic electronic", 2.0)
    assert r8["success"], "Exp 8 failed"
    print("Exp 8 OK | Audio bytes generated:", len(r8["wav_bytes"]))

    print("\n=== Testing Exp 9 (RAG Assistant) ===")
    r9 = run_experiment_9("", "What is the TRUST framework?", 500, 50, 2)
    assert r9["success"], "Exp 9 failed"
    print("Exp 9 OK | Retrieved chunks:", len(r9["retrieved_chunks"]))

    print("\n==============================================")
    print(">>> ALL RUNNERS VALIDATED AND TESTED OK! <<<")
    print("==============================================")

if __name__ == "__main__":
    main()
